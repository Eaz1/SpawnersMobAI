package com.you.spawnermobs;

import net.minecraft.server.v1_12_R1.EntitySpider;
import net.minecraft.server.v1_12_R1.PathfinderGoal;
import net.minecraft.server.v1_12_R1.PathfinderGoalClimb;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_12_R1.entity.CraftSpider;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Slime;
import org.bukkit.entity.Spider;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.ExplosionPrimeEvent;
import org.bukkit.event.entity.SpawnReason;
import org.bukkit.scheduler.BukkitRunnable;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class SpawnerListener implements Listener {

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpawn(EntitySpawnEvent event) {
        if (event.getEntity().getSpawnReason() != SpawnReason.SPAWNER) return;
        if (!(event.getEntity() instanceof LivingEntity)) return;

        LivingEntity entity = event.getEntity();

        // 1) Disable AI for every Mob → no movement, no targeting, no attacks.
        if (entity instanceof Mob) {
            ((Mob) entity).setAI(false);
        }

        // 2) Strip the climb goal from spiders so they can't climb walls.
        //    setAI(false) does NOT remove PathfinderGoalClimb — we have to do it via NMS.
        //    Deferred by 1 tick to ensure the entity is fully constructed before we touch its goals.
        if (entity instanceof Spider) {
            stripClimbGoal((Spider) entity);
        }

        // 3) Slimes / magma cubes → size 1 (defensive even with no AI)
        if (entity instanceof Slime) {
            ((Slime) entity).setSize(1);
        }

        // 4) Creepers → infinite fuse so they never explode.
        if (entity instanceof Creeper) {
            ((Creeper) entity).setMaxFuseTicks(Integer.MAX_VALUE);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCreeperPrime(ExplosionPrimeEvent event) {
        // Safety net: even if a creeper somehow primes, cancel it.
        if (event.getEntity().getSpawnReason() == SpawnReason.SPAWNER) {
            event.setCancelled(true);
        }
    }

    /**
     * Remove the PathfinderGoalClimb from a spider's NMS goal selectors.
     * Reflection is used because the goal list field name isn't part of the public API.
     */
    private void stripClimbGoal(Spider bukkitSpider) {
        // Capture a stable reference for the runnable
        final Spider spider = bukkitSpider;
        new BukkitRunnable() {
            @Override
            public void run() {
                // Bail out if the entity was unloaded before we got to it
                if (!spider.isValid() || spider.isDead()) return;

                EntitySpider nms = ((CraftSpider) spider).getHandle();

                Field[] fields = nms.getClass().getSuperclass().getDeclaredFields();
                for (Field f : fields) {
                    if (f.getType().getSimpleName().equals("PathfinderGoalSelector")) {
                        f.setAccessible(true);
                        Object selector;
                        try {
                            selector = f.get(nms);
                        } catch (IllegalAccessException e) {
                            continue;
                        }
                        // selector is a PathfinderGoalSelector; reach into its 'b' field (the goal list)
                        try {
                            Field goalsField = selector.getClass().getDeclaredField("b");
                            goalsField.setAccessible(true);
                            @SuppressWarnings("unchecked")
                            List<PathfinderGoal> goals = (List<PathfinderGoal>) goalsField.get(selector);
                            goals.removeIf(g -> g instanceof PathfinderGoalClimb);
                        } catch (NoSuchFieldException | IllegalAccessException ignored) {
                        }
                    }
                }
            }
        }.runTaskLater(com.you.spawnermobs.Main.getInstance(), 1L);
    }
}
