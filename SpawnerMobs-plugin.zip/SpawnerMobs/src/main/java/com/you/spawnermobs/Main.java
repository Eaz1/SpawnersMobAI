package com.you.spawnermobs;

import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    private static Main instance;

    @Override
    public void onEnable() {
        instance = this;
        getServer().getPluginManager().registerEvents(new SpawnerListener(), this);
        getLogger().info("SpawnerMobs enabled — spawner mobs neutered (no AI, no climb, no boom).");
    }

    @Override
    public void onDisable() {
        getLogger().info("SpawnerMobs disabled.");
        instance = null;
    }

    public static Main getInstance() {
        return instance;
    }
}
