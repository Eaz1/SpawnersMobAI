# SpawnerMobs

A Spigot 1.12.2 plugin that neuters all mobs spawned by spawners:

- No AI → mobs can't move, chase, or fight back.
- Spiders are stripped of their `PathfinderGoalClimb` → they stay alive but can no longer climb walls.
- Creepers get an infinite fuse → they never explode (with a safety-net `ExplosionPrimeEvent` cancel too).
- Slimes & magma cubes shrink to size 1.

## Build

Push to GitHub → Actions tab → download `SpawnerMobs-jar` artifact → drop `SpawnerMobs-1.0.0.jar` into your server's `plugins/` folder.

## Project layout

```
pom.xml
src/main/java/com/you/spawnermobs/Main.java
src/main/java/com/you/spawnermobs/SpawnerListener.java
src/main/resources/plugin.yml
.github/workflows/build.yml
```
